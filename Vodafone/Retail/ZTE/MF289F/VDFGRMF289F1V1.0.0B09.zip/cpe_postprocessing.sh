#!/bin/sh

PATH=/sbin:/bin:/usr/bin:/usr/sbin

echo "run cpe_postprocessing.sh"

echo "rm -rf /etc_rw/config/tree.xml"
rm -f /etc_rw/config/tree.xml
echo "rm -rf /etc_rw/config/tree_zdm.xml"
rm -f /etc_rw/config/tree_zdm.xml

echo "cpe_postprocessing complete !"



#Set the added and modified parameters
nv set tr069_CertEnable="1"
nv set voip_outbound_proxy="fwa.ngn.hol.net"
nv set voip_call_transfer_enable="1"
nv set sntp_timezone="2-1"
nv set sntp_dst_enable="1"
nv set sntp_dst_start="5_0_3_03_00_00"
nv set sntp_dst_end="5_0_10_04_00_00"
nv set sntp_dst_bias="01_00_00"
nv set sntp_auto_tz_dst_switch="1"
nv set cr_version="CR_VDFGRMF289F1V1.0.0B09"
nv set cr_inner_version="CR_VDFGRMF289F1V1.0.0B08"
nv set integrate_version="VDF_GR_MF289F1V1.0.0B08"
nv set integrate_release_version="VDF_GR_MF289F1V1.0.0B08"

#Save the set parameters
nv save
